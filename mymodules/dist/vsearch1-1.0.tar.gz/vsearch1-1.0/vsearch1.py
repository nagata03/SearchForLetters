def search_for_vowels(phrase:str) -> set:
    """ 入力された単語内の母音を返す。 """
    vowels = set('aeiou')
    return vowels.intersection(set(phrase))

#phrase = input('単語を入力してください。母音を探します。=> ')
#search_for_vowels(phrase)


def search_for_letters(phrase:str, letters:str='aeiou') -> set:
    """ phrase内のlettersの集合を返す。 """
    return set(letters).intersection(set(phrase))
