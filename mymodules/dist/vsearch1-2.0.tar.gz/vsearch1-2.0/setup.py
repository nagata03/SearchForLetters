from setuptools import setup

setup(
    name='vsearch1',
    version='2.0',
    description='The Search Tools',
    author='S.Nagata',
    author_email='hogehoge@gmail.com',
    url='hogehoge.com',
    py_modules=['vsearch1']
)
